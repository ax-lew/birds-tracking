Datos.xlsx
  Datos crudos provistos por Romina. Tiene 5 hojas, que bajé a 
  los siguientes archivos CSV.
  (No sé por qué la hoja RC1 aparece vacía, antes no estaba así.)

DatosCalibracion.csv
  Para cada punto, fecha, hora de inicio y de fin de la 
  calibración, y tag del emisor.

Datos{RC1,RC2,D1,D2}.csv
  Datos registrados por las cuatro antenas en los días de calibración.
  Tienen datos no sólo de los emisores de calibración, sino también
  de pájaros que andaban por ahí.

Datos{RC1,RC2,D1}_10k.csv
  Versiones chicas de los CSV.

Distances.xlsx
  Coordenadas de los puntos de calibración: geográficas, UTM y matriz
  de distancias entre los puntos.

DistancesCoordenadasUTM.csv
  Hoja "CoordenadasUTM" del Excel anterior, en formato CSV.

rec1 301217.TXT
  Log de un receptor (a modo de ejemplo).

